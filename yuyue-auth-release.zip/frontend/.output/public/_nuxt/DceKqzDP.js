import{D as e,aM as r,ae as t}from"./DoYQsA6H.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
