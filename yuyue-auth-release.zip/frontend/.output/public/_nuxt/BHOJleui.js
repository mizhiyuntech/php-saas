import"./DajVLaR1.js";const s=globalThis.setInterval;export{s};
