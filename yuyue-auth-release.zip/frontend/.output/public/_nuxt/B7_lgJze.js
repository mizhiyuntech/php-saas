import"./D3alepTt.js";const s=globalThis.setInterval;export{s};
