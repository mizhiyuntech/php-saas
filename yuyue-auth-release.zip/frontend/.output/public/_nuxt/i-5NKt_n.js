import{l as e,aL as r,ae as t}from"./C2UVJs24.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
