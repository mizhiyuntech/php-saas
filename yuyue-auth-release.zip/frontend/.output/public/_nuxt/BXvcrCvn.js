import{D as e,aM as r,ae as t}from"./D3alepTt.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
