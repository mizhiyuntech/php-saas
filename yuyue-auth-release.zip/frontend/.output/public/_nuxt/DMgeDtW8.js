import"./D4He1ud1.js";const s=globalThis.setInterval;export{s};
