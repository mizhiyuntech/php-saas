import{s as e,aL as r,ae as t}from"./C2inJ5tB.js";function s(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{s as u};
