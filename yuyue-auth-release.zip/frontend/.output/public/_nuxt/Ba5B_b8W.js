import{l as e,aK as r,ae as t}from"./Dne0Lkjs.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
