import"./DoYQsA6H.js";const s=globalThis.setInterval;export{s};
