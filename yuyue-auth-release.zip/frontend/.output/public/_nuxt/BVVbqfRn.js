import{D as e,aL as r,ae as t}from"./GjHj8n5B.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
