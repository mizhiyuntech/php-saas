import"./CuTW1BOk.js";const s=globalThis.setInterval;export{s};
