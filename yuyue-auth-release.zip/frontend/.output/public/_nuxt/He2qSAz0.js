import{D as e,aM as r,ae as t}from"./CuTW1BOk.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
